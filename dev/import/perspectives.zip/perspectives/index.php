<?php
/**
 * Created by PhpStorm.
 * User: Danila
 * Date: 2/24/2018
 * Time: 3:36 PM
 */
?>

<?php if (is_home()) {get_home();} ?>
