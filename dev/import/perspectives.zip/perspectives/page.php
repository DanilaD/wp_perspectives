<?php
/**
 * Created by PhpStorm.
 * User: Danila
 * Date: 2/24/2018
 * Time: 3:38 PM
 */
?>
<?php get_header();?>

<?php get_footer();?>