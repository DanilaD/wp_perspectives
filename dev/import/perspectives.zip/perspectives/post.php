<?php
/**
 * Created by PhpStorm.
 * User: Danila
 * Date: 2/25/2018
 * Time: 9:46 AM
 */

echo('Page');